
/*
  OpenEurope Demo (versione semplice)
  - Nessuna installazione: apri index.html
  - CSV: PapaParse
  - PDF: pdf.js (testo) + OCR (tesseract.js)
  - Grafici: Chart.js
  - PDF export: html2pdf.js
*/

(function () {
  const STORAGE_KEY = "openeurope_demo_v3";

  // ---------- Utils ----------
  const $ = (sel) => document.querySelector(sel);
  const $$ = (sel) => Array.from(document.querySelectorAll(sel));

  function nowISO() {
    const d = new Date();
    return d.toISOString();
  }

  function fmtNumber(x) {
    if (x === null || x === undefined || Number.isNaN(x)) return "—";
    const n = Number(x);
    return n.toLocaleString("it-IT", { maximumFractionDigits: 2 });
  }

  function safeFloat(v) {
    if (v === null || v === undefined) return null;
    if (typeof v === "number") return Number.isFinite(v) ? v : null;
    let s = String(v).trim();
    if (!s) return null;
    // handle Italian numbers like 1.234,56
    s = s.replace(/\s/g, "");
    s = s.replace(/\.(?=\d{3}(\D|$))/g, ""); // remove thousand separators
    s = s.replace(",", ".");
    const n = Number(s);
    return Number.isFinite(n) ? n : null;
  }

  function clamp(v, min, max) {
    if (v === null || v === undefined) return v;
    return Math.max(min, Math.min(max, v));
  }

  function downloadText(filename, text, mime = "text/plain") {
    const blob = new Blob([text], { type: mime });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = filename;
    document.body.appendChild(a);
    a.click();
    a.remove();
    URL.revokeObjectURL(url);
  }

  function downloadFileFromAssets(path, filename) {
    const a = document.createElement("a");
    a.href = path;
    a.download = filename || path.split("/").pop();
    document.body.appendChild(a);
    a.click();
    a.remove();
  }

  function setActiveStep(step) {
    $$(".step").forEach(btn => btn.classList.toggle("active", btn.dataset.step === String(step)));
    for (let i = 1; i <= 5; i++) {
      const panel = $("#step" + i);
      panel.classList.toggle("hidden", i !== step);
    }
    // refresh dashboard on open
    if (step === 4) {
      refreshDashboard();
      updateReportPreview();
    }
    if (step === 5) renderLog();
    persist();
  }

  function setTab(tab) {
    $$(".tab").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
    $("#tab_manual").classList.toggle("hidden", tab !== "manual");
    $("#tab_csv").classList.toggle("hidden", tab !== "csv");
    $("#tab_pdf").classList.toggle("hidden", tab !== "pdf");
    persist();
  }

  // ---------- Modal ----------
  const modal = $("#modal");
  const modalTitle = $("#modalTitle");
  const modalBody = $("#modalBody");
  const modalCancel = $("#modalCancel");
  const modalOk = $("#modalOk");
  let modalResolve = null;

  function confirmModal(title, body, okText = "OK", cancelText = "Annulla") {
    modalTitle.textContent = title;
    modalBody.innerHTML = body;
    modalOk.textContent = okText;
    modalCancel.textContent = cancelText;
    modal.classList.remove("hidden");
    return new Promise((resolve) => {
      modalResolve = resolve;
    });
  }

  modalCancel.addEventListener("click", () => {
    modal.classList.add("hidden");
    if (modalResolve) modalResolve(false);
  });
  modalOk.addEventListener("click", () => {
    modal.classList.add("hidden");
    if (modalResolve) modalResolve(true);
  });

  // ---------- State ----------
  const state = loadState();

  function defaultState() {
    const y = new Date().getFullYear();
    return {
      ui: { step: 1, tab: "manual" },
      project: {
        name: "OpenEurope — Demo",
        site: "",
        year: y,
        notes: ""
      },
      energy: [],     // {month:'YYYY-MM', f1,f2,f3, note, source}
      machines: [],   // {id, name, kW, eff, hoursYear, util, consFactor, note}
      log: []         // {ts,msg}
    };
  }

  function loadState() {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return defaultState();
      const obj = JSON.parse(raw);
      // minimal validation
      if (!obj.project || !obj.ui) return defaultState();
      obj.energy = Array.isArray(obj.energy) ? obj.energy : [];
      obj.machines = Array.isArray(obj.machines) ? obj.machines : [];
      obj.log = Array.isArray(obj.log) ? obj.log : [];
      return obj;
    } catch (e) {
      console.warn("State load failed:", e);
      return defaultState();
    }
  }

  function persist() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      console.warn("State save failed:", e);
    }
  }

  function log(msg) {
    state.log.unshift({ ts: nowISO(), msg });
    persist();
  }

  // ---------- Project ----------
  function bindProjectUI() {
    $("#projectName").value = state.project.name || "";
    $("#projectSite").value = state.project.site || "";
    $("#projectYear").value = state.project.year || new Date().getFullYear();
    $("#projectNotes").value = state.project.notes || "";
  }

  $("#btnSaveProject").addEventListener("click", () => {
    state.project.name = $("#projectName").value.trim() || "OpenEurope — Demo";
    state.project.site = $("#projectSite").value.trim();
    state.project.year = Number($("#projectYear").value) || new Date().getFullYear();
    state.project.notes = $("#projectNotes").value.trim();
    log(`Salvati dati progetto (${state.project.year})`);
    persist();
    // move to next step to keep flow
    setActiveStep(2);
  });

  $("#btnLoadDemo").addEventListener("click", async () => {
    const ok = await confirmModal(
      "Caricare dataset demo?",
      "Questa azione <b>sovrascrive</b> i dati attuali nel browser.",
      "Carica",
      "Annulla"
    );
    if (!ok) return;
    Object.assign(state, defaultState());
    state.project.name = "OpenEurope — Demo dataset";
    state.project.site = "Cliente demo — Stabilimento esempio";
    state.project.year = new Date().getFullYear();
    state.project.notes = "Dataset fittizio per dimostrazione: 12 mesi + 3 macchinari.";
    // energy demo
    const y = state.project.year;
    state.energy = [];
    for (let m = 1; m <= 12; m++) {
      const mm = String(m).padStart(2, "0");
      const base = 12000 + (Math.sin(m / 12 * Math.PI * 2) * 1500);
      const f1 = Math.max(0, base * 0.45 + (Math.random() * 300 - 150));
      const f2 = Math.max(0, base * 0.35 + (Math.random() * 250 - 125));
      const f3 = Math.max(0, base * 0.20 + (Math.random() * 200 - 100));
      state.energy.push({ month: `${y}-${mm}`, f1: round2(f1), f2: round2(f2), f3: round2(f3), note: "", source: "demo" });
    }
    // machines demo
    state.machines = [
      { id: uid(), name: "Compressore", kW: 45, eff: 0.92, hoursYear: 1800, util: 0.70, consFactor: 1.00, note: "turno singolo" },
      { id: uid(), name: "Forno", kW: 80, eff: 0.88, hoursYear: 1400, util: 0.60, consFactor: 1.05, note: "ciclo variabile" },
      { id: uid(), name: "Linea assemblaggio", kW: 25, eff: 0.95, hoursYear: 2000, util: 0.65, consFactor: 1.00, note: "" },
    ];
    state.log = [];
    log("Caricato dataset demo");
    bindProjectUI();
    renderEnergyTable();
    renderMachineTable();
    refreshDashboard();
    updateReportPreview();
    setActiveStep(4);
  });

  // ---------- Energy (manual / CSV / PDF) ----------
  function round2(n) {
    return Math.round((n + Number.EPSILON) * 100) / 100;
  }

  function normalizeMonth(m) {
    if (!m) return null;
    const s = String(m).trim();
    // accept YYYY-MM or YYYY/MM or YYYYMM
    const m1 = s.match(/^(\d{4})[-\/](\d{2})$/);
    if (m1) return `${m1[1]}-${m1[2]}`;
    const m2 = s.match(/^(\d{4})(\d{2})$/);
    if (m2) return `${m2[1]}-${m2[2]}`;
    // accept MM/YYYY
    const m3 = s.match(/^(\d{2})\/(\d{4})$/);
    if (m3) return `${m3[2]}-${m3[1]}`;
    return null;
  }

  function upsertEnergy(rec, askOverwrite = true) {
    const month = normalizeMonth(rec.month);
    if (!month) return { ok: false, reason: "Mese non valido" };
    const f1 = safeFloat(rec.f1) ?? 0;
    const f2 = safeFloat(rec.f2) ?? 0;
    const f3 = safeFloat(rec.f3) ?? 0;
    const note = rec.note || "";
    const source = rec.source || "manual";
    const idx = state.energy.findIndex(r => r.month === month);
    if (idx >= 0) {
      // overwrite existing
      state.energy[idx] = { month, f1: round2(f1), f2: round2(f2), f3: round2(f3), note, source };
      return { ok: true, overwritten: true };
    } else {
      state.energy.push({ month, f1: round2(f1), f2: round2(f2), f3: round2(f3), note, source });
      state.energy.sort((a, b) => a.month.localeCompare(b.month));
      return { ok: true, overwritten: false };
    }
  }

  function deleteEnergy(month) {
    state.energy = state.energy.filter(r => r.month !== month);
    log(`Eliminata riga consumi: ${month}`);
    persist();
    renderEnergyTable();
  }

  // Manual add
  $("#btnAddEnergyManual").addEventListener("click", async () => {
    const month = $("#manualMonth").value;
    const rec = {
      month,
      f1: $("#manualF1").value,
      f2: $("#manualF2").value,
      f3: $("#manualF3").value,
      note: $("#manualNote").value.trim(),
      source: "manuale"
    };
    const m = normalizeMonth(rec.month);
    if (!m) {
      alert("Inserisci un mese valido (YYYY-MM).");
      return;
    }
    const existing = state.energy.find(r => r.month === m);
    if (existing) {
      const ok = await confirmModal("Sovrascrivere il mese?", `Esistono già dati per <b>${m}</b>. Vuoi sovrascriverli?`, "Sì, sovrascrivi", "No");
      if (!ok) return;
    }
    upsertEnergy(rec);
    log(`Inseriti consumi manuali: ${m}`);
    persist();
    renderEnergyTable();
    refreshDashboard();
    $("#manualNote").value = "";
  });

  $("#btnClearEnergyManual").addEventListener("click", () => {
    $("#manualMonth").value = "";
    $("#manualF1").value = "";
    $("#manualF2").value = "";
    $("#manualF3").value = "";
    $("#manualNote").value = "";
  });

  function renderEnergyTable() {
    const tbody = $("#energyTable tbody");
    tbody.innerHTML = "";
    if (state.energy.length === 0) {
      const tr = document.createElement("tr");
      tr.innerHTML = `<td colspan="6" class="muted small">Nessun dato inserito.</td>`;
      tbody.appendChild(tr);
      return;
    }
    for (const r of state.energy) {
      const tot = (r.f1 || 0) + (r.f2 || 0) + (r.f3 || 0);
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td><b>${r.month}</b><br><small>${escapeHtml(r.source || "")}</small></td>
        <td>${fmtNumber(r.f1)}</td>
        <td>${fmtNumber(r.f2)}</td>
        <td>${fmtNumber(r.f3)}</td>
        <td><b>${fmtNumber(tot)}</b></td>
        <td>
          <button class="ghost smallbtn" data-act="edit" data-month="${r.month}">Modifica</button>
          <button class="ghost smallbtn" data-act="del" data-month="${r.month}">Elimina</button>
        </td>
      `;
      tbody.appendChild(tr);
    }

    tbody.querySelectorAll("button").forEach(btn => {
      btn.addEventListener("click", async () => {
        const act = btn.dataset.act;
        const month = btn.dataset.month;
        if (act === "del") {
          const ok = await confirmModal("Eliminare riga?", `Eliminare i consumi del mese <b>${month}</b>?`, "Elimina", "Annulla");
          if (!ok) return;
          deleteEnergy(month);
          refreshDashboard();
          return;
        }
        if (act === "edit") {
          const rec = state.energy.find(r => r.month === month);
          if (!rec) return;
          // populate manual inputs
          $("#manualMonth").value = rec.month;
          $("#manualF1").value = rec.f1 ?? "";
          $("#manualF2").value = rec.f2 ?? "";
          $("#manualF3").value = rec.f3 ?? "";
          $("#manualNote").value = rec.note ?? "";
          setTab("manual");
          setActiveStep(2);
        }
      });
    });
  }

  // CSV import preview state
  let csvPreviewRows = [];

  $("#fileCSV").addEventListener("change", (ev) => {
    const file = ev.target.files?.[0];
    if (!file) return;
    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (res) => {
        csvPreviewRows = parseCsvRows(res.data || []);
        renderCsvPreview();
        $("#btnConfirmCSVImport").disabled = csvPreviewRows.length === 0;
        $("#btnClearCSVPreview").disabled = csvPreviewRows.length === 0;
        log(`Caricato CSV: ${file.name} (anteprima)`);
      },
      error: (err) => {
        console.error(err);
        alert("Errore nella lettura del CSV.");
      }
    });
  });

  $("#btnDownloadSampleCSV").addEventListener("click", () => {
    downloadFileFromAssets("assets/sample_energy.csv", "sample_energy.csv");
  });

  $("#btnClearCSVPreview").addEventListener("click", () => {
    csvPreviewRows = [];
    renderCsvPreview();
    $("#btnConfirmCSVImport").disabled = true;
    $("#btnClearCSVPreview").disabled = true;
  });

  $("#btnConfirmCSVImport").addEventListener("click", async () => {
    if (csvPreviewRows.length === 0) return;
    // detect duplicates
    const duplicates = csvPreviewRows
      .map(r => normalizeMonth(r.month))
      .filter(m => m && state.energy.some(e => e.month === m));
    let overwriteAll = false;
    if (duplicates.length > 0) {
      const ok = await confirmModal(
        "Mesi già presenti",
        `Il CSV contiene mesi già presenti (<b>${[...new Set(duplicates)].join(", ")}</b>). Vuoi sovrascriverli?`,
        "Sì, sovrascrivi",
        "No"
      );
      if (!ok) return;
      overwriteAll = true;
    }
    let imported = 0;
    for (const r of csvPreviewRows) {
      const month = normalizeMonth(r.month);
      if (!month) continue;
      upsertEnergy({ ...r, month, source: "CSV" }, overwriteAll);
      imported++;
    }
    log(`Import CSV confermato: ${imported} righe`);
    csvPreviewRows = [];
    renderCsvPreview();
    $("#btnConfirmCSVImport").disabled = true;
    $("#btnClearCSVPreview").disabled = true;
    renderEnergyTable();
    refreshDashboard();
    setTab("manual");
  });

  function normalizeHeader(h) {
    return String(h || "").trim().toLowerCase();
  }

  function parseCsvRows(rows) {
    // Map possible column headers
    const out = [];
    for (const row of rows) {
      const keys = Object.keys(row || {});
      const map = {};
      for (const k of keys) map[normalizeHeader(k)] = row[k];

      const month = map["month"] ?? map["mese"] ?? map["period"] ?? map["periodo"] ?? map["ym"] ?? map["anno_mese"];
      const f1 = map["f1_kwh"] ?? map["f1"] ?? map["fascia1"] ?? map["f1 (kwh)"];
      const f2 = map["f2_kwh"] ?? map["f2"] ?? map["fascia2"] ?? map["f2 (kwh)"];
      const f3 = map["f3_kwh"] ?? map["f3"] ?? map["fascia3"] ?? map["f3 (kwh)"];

      const nm = normalizeMonth(month);
      const ok = Boolean(nm) && safeFloat(f1) !== null && safeFloat(f2) !== null && safeFloat(f3) !== null;
      out.push({
        month: nm || String(month || ""),
        f1: safeFloat(f1),
        f2: safeFloat(f2),
        f3: safeFloat(f3),
        note: "",
        _ok: ok
      });
    }
    return out;
  }

  function renderCsvPreview() {
    const tbody = $("#csvPreview tbody");
    tbody.innerHTML = "";
    if (csvPreviewRows.length === 0) {
      const tr = document.createElement("tr");
      tr.innerHTML = `<td colspan="6" class="muted small">Carica un CSV per vedere l’anteprima.</td>`;
      tbody.appendChild(tr);
      return;
    }
    csvPreviewRows.slice(0, 200).forEach((r, idx) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td>${idx + 1}</td>
        <td>${escapeHtml(r.month)}</td>
        <td>${fmtNumber(r.f1)}</td>
        <td>${fmtNumber(r.f2)}</td>
        <td>${fmtNumber(r.f3)}</td>
        <td>${r._ok ? "OK" : "<span class='muted'>Da verificare</span>"}</td>
      `;
      tbody.appendChild(tr);
    });
  }

  // ---------- PDF + OCR extraction ----------
  // pdf.js global
  let pdfjsLib = null;
  function ensurePdfJs() {
    if (pdfjsLib) return pdfjsLib;
    // pdf.js attaches to window.pdfjsLib in recent builds
    pdfjsLib = window.pdfjsLib;
    if (pdfjsLib && pdfjsLib.GlobalWorkerOptions) {
      pdfjsLib.GlobalWorkerOptions.workerSrc = "https://cdn.jsdelivr.net/npm/pdfjs-dist@4.10.38/build/pdf.worker.min.js";
    }
    return pdfjsLib;
  }

  let pdfExtractRows = []; // {source, month, f1,f2,f3, method, status}

  $("#btnDownloadSamplePDF").addEventListener("click", () => {
    // bundle: two demo PDFs
    downloadFileFromAssets("assets/bolletta_demo_testo.pdf", "bolletta_demo_testo.pdf");
    // anche versione “scansione” per test OCR
    setTimeout(() => downloadFileFromAssets("assets/bolletta_demo_scansione.pdf", "bolletta_demo_scansione.pdf"), 350);
  });

  $("#filePDF").addEventListener("change", async (ev) => {
    const files = Array.from(ev.target.files || []);
    if (files.length === 0) return;
    pdfExtractRows = [];
    renderPdfExtractTable();
    $("#btnConfirmPDFExtract").disabled = true;
    $("#btnClearPDFExtract").disabled = true;
    await processPdfFiles(files);
  });

  $("#btnClearPDFExtract").addEventListener("click", () => {
    pdfExtractRows = [];
    renderPdfExtractTable();
    $("#btnConfirmPDFExtract").disabled = true;
    $("#btnClearPDFExtract").disabled = true;
  });

  $("#btnConfirmPDFExtract").addEventListener("click", async () => {
    const valid = pdfExtractRows.filter(r => normalizeMonth(r.month) && isFiniteNum(r.f1) && isFiniteNum(r.f2) && isFiniteNum(r.f3));
    if (valid.length === 0) {
      alert("Nessuna riga valida da salvare. Correggi i campi e riprova.");
      return;
    }
    // check duplicates
    const duplicates = valid
      .map(r => normalizeMonth(r.month))
      .filter(m => m && state.energy.some(e => e.month === m));
    if (duplicates.length > 0) {
      const ok = await confirmModal(
        "Mesi già presenti",
        `Le bollette estratte contengono mesi già presenti (<b>${[...new Set(duplicates)].join(", ")}</b>). Vuoi sovrascriverli?`,
        "Sì, sovrascrivi",
        "No"
      );
      if (!ok) return;
    }
    let saved = 0;
    for (const r of valid) {
      const month = normalizeMonth(r.month);
      upsertEnergy({ month, f1: r.f1, f2: r.f2, f3: r.f3, note: "", source: `PDF (${r.method})` });
      saved++;
    }
    log(`Salvati da PDF: ${saved} mesi`);
    persist();
    renderEnergyTable();
    refreshDashboard();
    // reset extraction table
    pdfExtractRows = [];
    renderPdfExtractTable();
    $("#btnConfirmPDFExtract").disabled = true;
    $("#btnClearPDFExtract").disabled = true;
    setTab("manual");
  });

  function isFiniteNum(v) {
    const n = safeFloat(v);
    return n !== null && Number.isFinite(n);
  }

  function setProgress(pct, label) {
    const box = $("#pdfProgress");
    const bar = $("#pdfProgressBar");
    const lab = $("#pdfProgressLabel");
    box.classList.remove("hidden");
    bar.style.width = `${pct}%`;
    lab.textContent = label;
  }
  function hideProgress() {
    $("#pdfProgress").classList.add("hidden");
  }

  async function processPdfFiles(files) {
    ensurePdfJs();
    const total = files.length;
    let done = 0;
    for (const file of files) {
      done++;
      setProgress(Math.round((done - 1) / total * 100), `Apro ${file.name}…`);
      const row = await extractFromSinglePdf(file);
      pdfExtractRows.push(...row);
      renderPdfExtractTable();
      $("#btnConfirmPDFExtract").disabled = pdfExtractRows.length === 0;
      $("#btnClearPDFExtract").disabled = pdfExtractRows.length === 0;
      setProgress(Math.round(done / total * 100), `Completato ${file.name}`);
    }
    hideProgress();
    log(`Estrazione PDF completata: ${files.length} file`);
  }

  async function extractFromSinglePdf(file) {
    const pdfjs = ensurePdfJs();
    const rows = [];
    try {
      const ab = await file.arrayBuffer();
      const pdf = await pdfjs.getDocument({ data: ab }).promise;
      const numPages = pdf.numPages;

      // Try text extraction first (first 2 pages usually enough)
      let text = "";
      const maxTextPages = Math.min(numPages, 2);
      for (let p = 1; p <= maxTextPages; p++) {
        const page = await pdf.getPage(p);
        const tc = await page.getTextContent();
        const pageText = tc.items.map(it => it.str).join(" ");
        text += "\n" + pageText;
      }

      let method = "testo";
      let extracted = extractFasce(text);
      let month = extractMonth(text, state.project.year);

      // If text weak, do OCR
      const weak = !extracted.ok || (String(text).length < 120);
      if (weak) {
        method = "OCR";
        setProgress(0, `OCR in corso: ${file.name}…`);
        const ocrText = await ocrFirstPages(pdf, file.name);
        text = ocrText;
        extracted = extractFasce(text);
        month = month || extractMonth(text, state.project.year);
      }

      const row = {
        source: file.name,
        month: month || "",
        f1: extracted.f1 ?? "",
        f2: extracted.f2 ?? "",
        f3: extracted.f3 ?? "",
        method,
        status: extracted.ok ? "OK (verifica consigliata)" : "Da verificare"
      };
      rows.push(row);
      return rows;
    } catch (e) {
      console.error("PDF error:", e);
      rows.push({
        source: file.name,
        month: "",
        f1: "",
        f2: "",
        f3: "",
        method: "—",
        status: "Errore lettura"
      });
      return rows;
    }
  }

  async function ocrFirstPages(pdf, label) {
    // OCR first pages (max 2) for speed
    const maxPages = Math.min(pdf.numPages, 2);
    let all = "";
    for (let p = 1; p <= maxPages; p++) {
      setProgress(Math.round((p - 1) / maxPages * 100), `OCR pagina ${p}/${maxPages} — ${label}`);
      const page = await pdf.getPage(p);
      const viewport = page.getViewport({ scale: 2.0 });
      const canvas = document.createElement("canvas");
      const ctx = canvas.getContext("2d");
      canvas.width = viewport.width;
      canvas.height = viewport.height;
      await page.render({ canvasContext: ctx, viewport }).promise;

      const text = await Tesseract.recognize(canvas, "ita", {
        logger: (m) => {
          if (m.status === "recognizing text") {
            const pct = Math.round((p - 1) / maxPages * 100 + (m.progress || 0) * (100 / maxPages));
            setProgress(clamp(pct, 0, 100), `OCR… ${Math.round((m.progress || 0) * 100)}% — ${label}`);
          }
        }
      }).then(r => r.data.text || "");
      all += "\n" + text;
    }
    setProgress(100, `OCR completato — ${label}`);
    return all;
  }

  function extractFasce(rawText) {
    const text = normalizeText(rawText);

    // patterns: "F1 1234 kWh", "F1: 1234", "kWh F1 1234", "F1 (kWh) 1234"
    const patterns = [
      { key: "f1", rx: /(?:\bF1\b[\s:=-]*)([\d\.\,]+)\s*(?:kwh|k\s*wh)?/i },
      { key: "f2", rx: /(?:\bF2\b[\s:=-]*)([\d\.\,]+)\s*(?:kwh|k\s*wh)?/i },
      { key: "f3", rx: /(?:\bF3\b[\s:=-]*)([\d\.\,]+)\s*(?:kwh|k\s*wh)?/i },
      { key: "f1b", rx: /([\d\.\,]+)\s*(?:kwh|k\s*wh)\s*(?:\bF1\b)/i },
      { key: "f2b", rx: /([\d\.\,]+)\s*(?:kwh|k\s*wh)\s*(?:\bF2\b)/i },
      { key: "f3b", rx: /([\d\.\,]+)\s*(?:kwh|k\s*wh)\s*(?:\bF3\b)/i },
    ];

    function matchF(rx) {
      const m = text.match(rx);
      if (!m) return null;
      return safeFloat(m[1]);
    }

    let f1 = matchF(patterns[0].rx) ?? matchF(patterns[3].rx);
    let f2 = matchF(patterns[1].rx) ?? matchF(patterns[4].rx);
    let f3 = matchF(patterns[2].rx) ?? matchF(patterns[5].rx);

    const ok = [f1, f2, f3].every(v => v !== null && Number.isFinite(v));
    return { ok, f1, f2, f3 };
  }

  function normalizeText(t) {
    return String(t || "")
      .replace(/\u00A0/g, " ")
      .replace(/[’']/g, "'")
      .replace(/\s+/g, " ")
      .trim();
  }

  function extractMonth(text, fallbackYear) {
    const t = String(text || "");
    // 1) Try date range dd/mm/yyyy ... dd/mm/yyyy
    const dates = Array.from(t.matchAll(/(\d{1,2})\/(\d{1,2})\/(\d{4})/g)).map(m => ({
      d: Number(m[1]), m: Number(m[2]), y: Number(m[3])
    }));
    if (dates.length >= 1) {
      // choose the first date as period start
      const d0 = dates[0];
      const mm = String(d0.m).padStart(2, "0");
      return `${d0.y}-${mm}`;
    }

    // 2) Italian month names + year
    const months = {
      "gennaio": "01", "febbraio": "02", "marzo": "03", "aprile": "04",
      "maggio": "05", "giugno": "06", "luglio": "07", "agosto": "08",
      "settembre": "09", "ottobre": "10", "novembre": "11", "dicembre": "12"
    };
    for (const [name, num] of Object.entries(months)) {
      const rx = new RegExp(`\\b${name}\\b\\s*(\\d{4})`, "i");
      const m = t.match(rx);
      if (m) return `${m[1]}-${num}`;
    }

    // 3) "MM-YYYY" or "MM/YYYY"
    const m3 = t.match(/\b(0?[1-9]|1[0-2])[-\/](\d{4})\b/);
    if (m3) {
      const mm = String(Number(m3[1])).padStart(2, "0");
      return `${m3[2]}-${mm}`;
    }

    // 4) If only month number appears with fallback year (rare)
    if (fallbackYear) {
      const m4 = t.match(/\b(0?[1-9]|1[0-2])\b/);
      if (m4) {
        const mm = String(Number(m4[1])).padStart(2, "0");
        return `${fallbackYear}-${mm}`;
      }
    }

    return null;
  }

  function renderPdfExtractTable() {
    const tbody = $("#pdfExtractTable tbody");
    tbody.innerHTML = "";
    if (pdfExtractRows.length === 0) {
      const tr = document.createElement("tr");
      tr.innerHTML = `<td colspan="7" class="muted small">Carica uno o più PDF per vedere i risultati.</td>`;
      tbody.appendChild(tr);
      return;
    }

    pdfExtractRows.forEach((r, idx) => {
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td><b>${escapeHtml(r.source)}</b></td>
        <td><input class="miniinput" data-k="month" data-i="${idx}" value="${escapeAttr(r.month || "")}" placeholder="YYYY-MM"></td>
        <td><input class="miniinput" data-k="f1" data-i="${idx}" value="${escapeAttr(r.f1 ?? "")}" placeholder="kWh"></td>
        <td><input class="miniinput" data-k="f2" data-i="${idx}" value="${escapeAttr(r.f2 ?? "")}" placeholder="kWh"></td>
        <td><input class="miniinput" data-k="f3" data-i="${idx}" value="${escapeAttr(r.f3 ?? "")}" placeholder="kWh"></td>
        <td><small>${escapeHtml(r.method || "")}</small></td>
        <td><small>${escapeHtml(r.status || "")}</small></td>
      `;
      tbody.appendChild(tr);
    });

    tbody.querySelectorAll("input.miniinput").forEach(inp => {
      inp.addEventListener("input", () => {
        const i = Number(inp.dataset.i);
        const k = inp.dataset.k;
        if (!pdfExtractRows[i]) return;
        pdfExtractRows[i][k] = inp.value;
      });
    });
  }

  // ---------- Machines ----------
  function uid() {
    return Math.random().toString(16).slice(2) + Math.random().toString(16).slice(2);
  }

  function computeHoursYear(hoursYear, hoursDay, daysYear) {
    const hy = safeFloat(hoursYear);
    if (hy !== null) return hy;
    const hd = safeFloat(hoursDay);
    const dy = safeFloat(daysYear);
    if (hd !== null && dy !== null) return hd * dy;
    return null;
  }

  function normEff(eff) {
    let e = safeFloat(eff);
    if (e === null) return 1;
    if (e > 1.5) e = e / 100; // treat as %
    e = clamp(e, 0.05, 1.0);
    return e;
  }

  function computeMachineKwh(m) {
    const kW = safeFloat(m.kW) ?? 0;
    const eff = normEff(m.eff);
    const hours = safeFloat(m.hoursYear) ?? 0;
    const util = clamp(safeFloat(m.util) ?? 1, 0, 1);
    const cf = safeFloat(m.consFactor) ?? 1;
    if (eff <= 0) return 0;
    const kwh = (kW * hours * util * cf) / eff;
    return round2(kwh);
  }

  $("#btnAddMachine").addEventListener("click", async () => {
    const name = $("#mName").value.trim();
    if (!name) { alert("Inserisci un nome macchinario."); return; }

    const kW = safeFloat($("#mKW").value);
    const eff = $("#mEff").value;
    const hoursYear = computeHoursYear($("#mHoursYear").value, $("#mHoursDay").value, $("#mDaysYear").value);
    const util = safeFloat($("#mUtil").value);
    const cf = safeFloat($("#mConsFactor").value);

    if (kW === null || hoursYear === null) {
      alert("Inserisci almeno kW e ore annue (oppure ore/giorno + giorni/anno).");
      return;
    }
    const machine = {
      id: uid(),
      name,
      kW,
      eff: eff === "" ? 1 : safeFloat(eff) ?? 1,
      hoursYear,
      util: util === null ? 1 : util,
      consFactor: cf === null ? 1 : cf,
      note: $("#mNote").value.trim()
    };
    state.machines.push(machine);
    log(`Aggiunto macchinario: ${name}`);
    persist();
    renderMachineTable();
    refreshDashboard();
    $("#btnClearMachine").click();
  });

  $("#btnClearMachine").addEventListener("click", () => {
    $("#mName").value = "";
    $("#mKW").value = "";
    $("#mEff").value = "";
    $("#mHoursYear").value = "";
    $("#mHoursDay").value = "";
    $("#mDaysYear").value = "";
    $("#mUtil").value = "";
    $("#mConsFactor").value = "";
    $("#mNote").value = "";
  });

  function renderMachineTable() {
    const tbody = $("#machineTable tbody");
    tbody.innerHTML = "";
    if (state.machines.length === 0) {
      const tr = document.createElement("tr");
      tr.innerHTML = `<td colspan="8" class="muted small">Nessun macchinario inserito.</td>`;
      tbody.appendChild(tr);
      return;
    }
    state.machines.forEach(m => {
      const kwh = computeMachineKwh(m);
      const tr = document.createElement("tr");
      tr.innerHTML = `
        <td><b>${escapeHtml(m.name)}</b><br><small>${escapeHtml(m.note || "")}</small></td>
        <td>${fmtNumber(m.kW)}</td>
        <td>${fmtNumber(m.hoursYear)}</td>
        <td>${fmtNumber(m.util ?? 1)}</td>
        <td>${fmtNumber(m.consFactor ?? 1)}</td>
        <td>${fmtNumber(normEff(m.eff))}</td>
        <td><b>${fmtNumber(kwh)}</b></td>
        <td>
          <button class="ghost smallbtn" data-act="del" data-id="${m.id}">Elimina</button>
        </td>
      `;
      tbody.appendChild(tr);
    });
    tbody.querySelectorAll("button").forEach(btn => {
      btn.addEventListener("click", async () => {
        const id = btn.dataset.id;
        const ok = await confirmModal("Eliminare macchinario?", "Confermi eliminazione?", "Elimina", "Annulla");
        if (!ok) return;
        const m = state.machines.find(x => x.id === id);
        state.machines = state.machines.filter(x => x.id !== id);
        log(`Eliminato macchinario: ${m?.name || id}`);
        persist();
        renderMachineTable();
        refreshDashboard();
      });
    });
  }

  // ---------- Dashboard & Report ----------
  let chartMonthly = null;
  let chartShare = null;
  let chartMonthlyReport = null;
  let chartShareReport = null;

  function monthsOfYear(year) {
    const arr = [];
    for (let m = 1; m <= 12; m++) arr.push(`${year}-${String(m).padStart(2, "0")}`);
    return arr;
  }

  function aggregateEnergy() {
    const y = state.project.year || new Date().getFullYear();
    const months = monthsOfYear(y);
    const byMonth = {};
    months.forEach(m => byMonth[m] = { f1: 0, f2: 0, f3: 0 });
    for (const r of state.energy) {
      if (!r.month || !r.month.startsWith(String(y))) continue;
      if (!byMonth[r.month]) byMonth[r.month] = { f1: 0, f2: 0, f3: 0 };
      byMonth[r.month].f1 += safeFloat(r.f1) ?? 0;
      byMonth[r.month].f2 += safeFloat(r.f2) ?? 0;
      byMonth[r.month].f3 += safeFloat(r.f3) ?? 0;
    }
    const series = months.map(m => ({ month: m, ...byMonth[m] }));
    const total = series.reduce((acc, x) => {
      acc.f1 += x.f1; acc.f2 += x.f2; acc.f3 += x.f3;
      return acc;
    }, { f1: 0, f2: 0, f3: 0 });
    total.tot = total.f1 + total.f2 + total.f3;
    return { months, series, total };
  }

  function sumMachines() {
    return state.machines.reduce((acc, m) => acc + computeMachineKwh(m), 0);
  }

  function refreshDashboard() {
    const ag = aggregateEnergy();
    $("#kpiF1").textContent = fmtNumber(ag.total.f1);
    $("#kpiF2").textContent = fmtNumber(ag.total.f2);
    $("#kpiF3").textContent = fmtNumber(ag.total.f3);
    $("#kpiTot").textContent = fmtNumber(ag.total.tot);

    const bills = ag.total.tot;
    const mach = sumMachines();
    $("#kpiBills").textContent = fmtNumber(bills);
    $("#kpiMachines").textContent = fmtNumber(mach);
    const delta = bills - mach;
    $("#kpiDelta").textContent = `${fmtNumber(delta)} kWh`;

    renderCharts(ag);
    updateReportPreview();
  }

  function renderCharts(ag) {
    const labels = ag.months.map(m => m.slice(5)); // month number
    const f1 = ag.series.map(x => round2(x.f1));
    const f2 = ag.series.map(x => round2(x.f2));
    const f3 = ag.series.map(x => round2(x.f3));

    // Monthly (stacked bar)
    if (chartMonthly) chartMonthly.destroy();
    chartMonthly = new Chart($("#chartMonthly"), {
      type: "bar",
      data: {
        labels,
        datasets: [
          { label: "F1", data: f1, stack: "kwh" },
          { label: "F2", data: f2, stack: "kwh" },
          { label: "F3", data: f3, stack: "kwh" },
        ]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: "bottom" } },
        scales: { x: { stacked: true }, y: { stacked: true } }
      }
    });

    // Share (doughnut)
    if (chartShare) chartShare.destroy();
    chartShare = new Chart($("#chartShare"), {
      type: "doughnut",
      data: {
        labels: ["F1", "F2", "F3"],
        datasets: [{ data: [round2(ag.total.f1), round2(ag.total.f2), round2(ag.total.f3)] }]
      },
      options: { responsive: true, plugins: { legend: { position: "bottom" } } }
    });

    // Report charts (separati)
    if (chartMonthlyReport) chartMonthlyReport.destroy();
    chartMonthlyReport = new Chart($("#chartMonthlyReport"), {
      type: "bar",
      data: {
        labels,
        datasets: [
          { label: "F1", data: f1, stack: "kwh" },
          { label: "F2", data: f2, stack: "kwh" },
          { label: "F3", data: f3, stack: "kwh" },
        ]
      },
      options: {
        responsive: true,
        plugins: { legend: { position: "bottom" } },
        scales: { x: { stacked: true }, y: { stacked: true } }
      }
    });

    if (chartShareReport) chartShareReport.destroy();
    chartShareReport = new Chart($("#chartShareReport"), {
      type: "doughnut",
      data: {
        labels: ["F1", "F2", "F3"],
        datasets: [{ data: [round2(ag.total.f1), round2(ag.total.f2), round2(ag.total.f3)] }]
      },
      options: { responsive: true, plugins: { legend: { position: "bottom" } } }
    });
  }

  function updateReportPreview() {
    const ag = aggregateEnergy();
    $("#rTitle").textContent = state.project.name || "OpenEurope — Report";
    const site = state.project.site ? ` • ${state.project.site}` : "";
    $("#rSub").textContent = `Profilo consumi elettrici per fasce (F1/F2/F3)${site}`;
    $("#rGenerated").textContent = new Date().toLocaleString("it-IT");
    $("#rYear").textContent = String(state.project.year || "");

    $("#rF1").textContent = `${fmtNumber(ag.total.f1)} kWh`;
    $("#rF2").textContent = `${fmtNumber(ag.total.f2)} kWh`;
    $("#rF3").textContent = `${fmtNumber(ag.total.f3)} kWh`;
    $("#rTot").textContent = `${fmtNumber(ag.total.tot)} kWh`;

    // Machines table in report
    const tbody = $("#reportMachineTable tbody");
    tbody.innerHTML = "";
    if (state.machines.length === 0) {
      const tr = document.createElement("tr");
      tr.innerHTML = `<td colspan="7" class="muted small">Nessun macchinario inserito.</td>`;
      tbody.appendChild(tr);
    } else {
      state.machines.forEach(m => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
          <td><b>${escapeHtml(m.name)}</b></td>
          <td>${fmtNumber(m.kW)}</td>
          <td>${fmtNumber(m.hoursYear)}</td>
          <td>${fmtNumber(m.util ?? 1)}</td>
          <td>${fmtNumber(m.consFactor ?? 1)}</td>
          <td>${fmtNumber(normEff(m.eff))}</td>
          <td><b>${fmtNumber(computeMachineKwh(m))}</b></td>
        `;
        tbody.appendChild(tr);
      });
    }

    const notes = state.project.notes?.trim() || "—";
    $("#rNotes").textContent = notes;
  }

  // ---------- Export / Import ----------
  $("#btnExportJSON").addEventListener("click", () => {
    const payload = JSON.stringify(state, null, 2);
    const fn = `OpenEurope_${(state.project.name || "progetto").replace(/[^\w\-]+/g, "_")}.json`;
    downloadText(fn, payload, "application/json");
    log("Esportati dati progetto (JSON)");
  });

  $("#fileImportJSON").addEventListener("change", async (ev) => {
    const file = ev.target.files?.[0];
    if (!file) return;
    try {
      const txt = await file.text();
      const obj = JSON.parse(txt);
      if (!obj.project || !obj.ui) throw new Error("Formato non valido");
      // merge
      state.ui = obj.ui || state.ui;
      state.project = obj.project || state.project;
      state.energy = Array.isArray(obj.energy) ? obj.energy : [];
      state.machines = Array.isArray(obj.machines) ? obj.machines : [];
      state.log = Array.isArray(obj.log) ? obj.log : [];
      persist();
      bindProjectUI();
      renderEnergyTable();
      renderMachineTable();
      refreshDashboard();
      setActiveStep(state.ui.step || 1);
      setTab(state.ui.tab || "manual");
      log(`Importato progetto JSON: ${file.name}`);
    } catch (e) {
      console.error(e);
      alert("Errore: file JSON non valido.");
    } finally {
      ev.target.value = "";
    }
  });

  $("#btnExportPDF").addEventListener("click", async () => {
    updateReportPreview();
    const name = (state.project.name || "OpenEurope_Report").replace(/[^\w\-]+/g, "_");
    const filename = `${name}_${state.project.year || ""}.pdf`;
    log("Avviata esportazione report PDF");
    await exportReportPDF(filename);
  });

  async function exportReportPDF(filename) {
    const el = $("#reportArea");
    // Ensure charts are rendered before capture
    await new Promise(r => setTimeout(r, 250));
    const opt = {
      margin: 10,
      filename,
      image: { type: "jpeg", quality: 0.95 },
      html2canvas: { scale: 2, useCORS: true },
      jsPDF: { unit: "mm", format: "a4", orientation: "portrait" }
    };
    try {
      await html2pdf().set(opt).from(el).save();
      log(`Report PDF generato: ${filename}`);
    } catch (e) {
      console.error(e);
      alert("Errore durante l'esportazione PDF. Prova con Chrome/Edge.");
    }
  }

  // ---------- Audit log ----------
  function renderLog() {
    const box = $("#auditLog");
    box.innerHTML = "";
    if (state.log.length === 0) {
      box.innerHTML = `<div class="item"><div class="muted">Nessun evento.</div></div>`;
      return;
    }
    state.log.slice(0, 250).forEach(item => {
      const div = document.createElement("div");
      div.className = "item";
      div.innerHTML = `<div>${escapeHtml(item.msg)}</div><div class="ts">${escapeHtml(new Date(item.ts).toLocaleString("it-IT"))}</div>`;
      box.appendChild(div);
    });
  }

  $("#btnClearLog").addEventListener("click", async () => {
    const ok = await confirmModal("Svuotare audit log?", "Confermi la cancellazione del log?", "Svuota", "Annulla");
    if (!ok) return;
    state.log = [];
    persist();
    renderLog();
  });

  // ---------- Navigation wiring ----------
  $$(".step").forEach(btn => {
    btn.addEventListener("click", () => {
      const step = Number(btn.dataset.step);
      state.ui.step = step;
      setActiveStep(step);
    });
  });

  $$(".tab").forEach(btn => {
    btn.addEventListener("click", () => {
      const tab = btn.dataset.tab;
      state.ui.tab = tab;
      setTab(tab);
    });
  });

  // ---------- Minor UI helpers ----------
  function escapeHtml(s) {
    return String(s ?? "").replace(/[&<>"']/g, (m) => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#039;"
    }[m]));
  }
  function escapeAttr(s) {
    return escapeHtml(s).replace(/"/g, "&quot;");
  }

  // ---------- Init ----------
  // Set year default in UI if empty
  if (!state.project.year) state.project.year = new Date().getFullYear();
  bindProjectUI();
  renderEnergyTable();
  renderMachineTable();

  // Restore UI
  setActiveStep(state.ui.step || 1);
  setTab(state.ui.tab || "manual");

  // Quick hint: set manual month default to Jan of year
  const y = state.project.year || new Date().getFullYear();
  if (!$("#manualMonth").value) $("#manualMonth").value = `${y}-01`;

  // Add some CSS for small buttons without making a whole style system
  const style = document.createElement("style");
  style.textContent = `.smallbtn{padding:6px 8px;border-radius:10px;font-weight:800;font-size:12px}`;
  document.head.appendChild(style);

})();
